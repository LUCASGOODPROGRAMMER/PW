function gtr34() 
{
    alert("MEU PRIMEIRO SITE")
    

    

}